
import { useState } from "react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";

const questions = [
  { id: 1, text: "Is this communication personal or professional?", options: [
    { label: "Personal", next: 2 },
    { label: "Professional", next: 6 },
  ] },
  { id: 2, text: "Is it urgent?", options: [
    { label: "Yes", result: ["Phone Call", "WhatsApp Call", "FaceTime"] },
    { label: "No", next: 3 },
  ] },
  { id: 3, text: "Is it private or sensitive?", options: [
    { label: "Yes", result: ["Signal", "iMessage", "In-person"] },
    { label: "No", next: 4 },
  ] },
  { id: 4, text: "Is it visual (photo, video)?", options: [
    { label: "Yes", result: ["Instagram", "Snapchat", "YouTube"] },
    { label: "No", next: 5 },
  ] },
  { id: 5, text: "Do you want to reach multiple people?", options: [
    { label: "Yes", result: ["WhatsApp Group", "Facebook Post"] },
    { label: "No", result: ["SMS", "WhatsApp", "Messenger"] },
  ] },
  { id: 6, text: "Is it time-sensitive or requires instant action?", options: [
    { label: "Yes", result: ["Slack", "Teams Chat", "Phone Call"] },
    { label: "No", next: 7 },
  ] },
  { id: 7, text: "Does it need to be formal and recorded?", options: [
    { label: "Yes", result: ["Email", "Memo", "Formal Letter"] },
    { label: "No", next: 8 },
  ] },
  { id: 8, text: "Is it for collaborative discussion or a meeting?", options: [
    { label: "Yes", result: ["Zoom", "Google Meet", "Microsoft Teams"] },
    { label: "No", next: 9 },
  ] },
  { id: 9, text: "Is it a broadcast update to a team or audience?", options: [
    { label: "Yes", result: ["Company Email", "LinkedIn Post"] },
    { label: "No", next: 10 },
  ] },
  { id: 10, text: "Is it collaborative document or task tracking?", options: [
    { label: "Yes", result: ["Google Docs", "Notion", "Trello"] },
    { label: "No", result: ["Internal Chat", "Slack", "Quick Call"] },
  ] },
];

export default function CommunicationSelector() {
  const [step, setStep] = useState(1);
  const [results, setResults] = useState(null);

  const current = questions.find((q) => q.id === step);

  const handleSelect = (option) => {
    if (option.next) setStep(option.next);
    if (option.result) setResults(option.result);
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      {results ? (
        <div>
          <h2 className="text-xl font-bold mb-2">Suggested Channels:</h2>
          <ul className="list-disc list-inside">
            {results.map((channel, index) => (
              <li key={index}>{channel}</li>
            ))}
          </ul>
          <Button className="mt-4" onClick={() => { setStep(1); setResults(null); }}>
            Start Over
          </Button>
        </div>
      ) : (
        <div>
          <h2 className="text-xl font-bold mb-4">{current.text}</h2>
          {current.options.map((option, idx) => (
            <Button key={idx} onClick={() => handleSelect(option)} className="w-full mb-2">
              {option.label}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}
